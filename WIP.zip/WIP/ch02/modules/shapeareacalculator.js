const Calculator = require('./calculator.js');
const calc = new Calculator();
module.exports = class ShapeAreaCalculator {
    areaOfCircle(radius) {
        return 3.14 * calc.multiply(radius,radius)
    }

    areaOfSquare(width) {
        return calc.multiply(width, width);
    }
    areaOfTriangle(base, height) {
        return (calc.multiply(calc.multiply(0.5, base) , height));
    }
}
