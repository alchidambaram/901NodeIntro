const ShapeCalculator = require('./shapeareacalculator.js');
const myShapeCalc = new ShapeCalculator();
console.log(`Area of Square is ${myShapeCalc.areaOfSquare(3)}`);
console.log(`Area of Circle is ${myShapeCalc.areaOfCircle(3)}`);
console.log(`Area of triangle is ${myShapeCalc.areaOfCircle(7,5)}`);