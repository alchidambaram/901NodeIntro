const bands = require('./constructor-band.js');
console.log(bands.memberCount);