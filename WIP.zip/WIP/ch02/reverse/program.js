const Reverse = require('./module.js');
const rev = new Reverse(process.argv[2]);
console.log(`process argv 2 : ${process.argv[2]}`);
console.log(rev.revereString());
