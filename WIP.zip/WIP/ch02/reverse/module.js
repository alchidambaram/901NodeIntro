function Reverse(inputString) {
    this.inputString = inputString;
}

Reverse.prototype.revereString = function reverse() {
    let reversedString = "";
    for (let p = this.inputString.length-1; p >= 0; p--) {
        reversedString += this.inputString[p];
    }
    return reversedString;
}

module.exports = Reverse;