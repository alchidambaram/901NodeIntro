const  ConvertUpperCase = require('./convertUpperCase.js');
const upperCase = new ConvertUpperCase(process.argv[2]);
