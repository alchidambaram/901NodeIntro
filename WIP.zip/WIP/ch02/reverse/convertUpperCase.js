function ConvertUpperCase(inputArray) {
    this.inputArray = inputArray;
}

ConvertUpperCase.prototype.convertCase = function ConvertUpperCase() {
    
    for (let p = 0; p < this.inputinputArray.length; p++) {
      let argument =   this.inputArray[p];
      for (let s =0; s < s.argument.length; s++) {
        argument = argument[s]
      }
    }
    return this.inputArray;
}

module.exports = ConvertUpperCase;