const os= require('os')
console.log(`OS total memory : ${os.totalmem()}`);
console.log(`OS free memory : ${os.freemem()}`);