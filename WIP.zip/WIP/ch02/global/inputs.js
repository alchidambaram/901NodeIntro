console.log(`current running file : ${__filename}`);
console.log(`current running directory : ${__dirname}`);
console.log(`Process argv 0 is ${process.argv[0]}`);
console.log(`Process argv 1 is ${process.argv[1]}`)
