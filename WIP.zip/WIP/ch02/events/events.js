let events = require('events');
//create eventemmitter
let workEventEmmitter = new events.EventEmitter();


workEventEmmitter.once('tdd_event', function () {
    console.log('********************');
    console.log(`Clocking in`);
})

let handler = workEventEmmitter.on('tdd_event', function () {
    console.log(`Write Tests`);
    console.log(`Code`);
    console.log(`Refactor`);
    console.log(`Go to Meeting`);
    console.log('********************');
});

let breakHandler = workEventEmmitter.on('break_event', () => {
  console.log(`Check Emails`);
});
// handler.emit('Clocking_event');
handler.emit('tdd_event');
handler.emit('Clocking_event');
handler.emit('tdd_event');
breakHandler.emit('break_event');

