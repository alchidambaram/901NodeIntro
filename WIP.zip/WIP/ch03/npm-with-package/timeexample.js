var moment = require('moment');
var momenttz = require('moment-timezone');
console.log(moment().format('MM-DD-YYYY'));
console.log(moment("20110101", "YYYYMMDD").fromNow());
var est = momenttz().tz('America/New_York').format('ha z');
var pst = momenttz().tz('America/Los_Angeles').format('ha z');
console.log(`Eastern TimeZone ${est}`);
console.log(`Pacific TimeZone ${pst}`);