const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));
Promise.try(() => {
    return db.schema.createTable("customer", (table)  => {
        table.increments("id").primary();
        table.text("firstname");
        table.text("lastname");
        table.text("email");
    });
}).then(() => {
    console.log("Table Created!")
    console.log("Inserting data into customer");
    return db("customer").insert([
        {firstname: "Joe", lastname: "Doe", email:"jdoe@proxie.com"},
        {firstname: "Karl", lastname: "Moxie", email:"kmoxie@proxie.com"},
    ])
    
}).then(() => {
  return db("customer");
}).then((customer) => {
console.log("All customers : ", customer);
}).finally(() => {
    db.destroy();
});