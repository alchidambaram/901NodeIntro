const http = require("http");
const weather = require('./weather.json');
const Promise = require("bluebird");
const fs = Promise.promisifyAll(require("fs"));
const server = http.createServer();
server.on('request', (request, response) => {
    // response.end('Hello Universe');
let weatherArray = [];
Promise.try(() => {
    return fs.readFileSync("weather.json");
}).then((data) => {
    // weatherArray = JSON.parse(data);
    console.log(`Weather Array : ${data}`);
    response.end(data);
}).catch((err) => {
    console.log(`Error: err`);
})  
   
});

server.listen(3131, (err) => {  
    if (err) {
        return console.log('something bad happened', err);
    }

    console.log(`server is listening on 3131 : http://localhost:3131`);
    // return console.log(weatherArray = [{day:"Monday", high:102, low:90},
    //                         {day:"Tuesday", high:90, low:70},
    //                     {day:"Wednesday", high:85, low:10}]);
    })

