var p = 'this is a string';
console.log(p);