console.log(first([7, 9, 0, -2]));
console.log(first([], 3));
console.log(first([7, 9, 0, -2], 3));
console.log(first([7, 9, 0, -2], 6));
console.log(first([7, 9, 0, -2], -3));
function first(testArray, n) {
    if (n > 0) {
        return testArray.slice(0, n);
    } else if (n < 0) {
        return [];
    } else {
        return testArray[0];
    }
}