var animals = ['cat', 'dog', 'rat'];
for (let p =0; p < animals.length; p++) {
    animals[p] = animals[p] + 's';
}
console.log(animals);