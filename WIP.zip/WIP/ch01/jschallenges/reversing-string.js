var p = 'pizza is alright';
p = p.replace('alright', 'wonderful');
console.log(p);