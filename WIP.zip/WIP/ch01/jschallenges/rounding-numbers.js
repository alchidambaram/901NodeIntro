let roundUp=1.5;
console.log(Math.round(roundUp));