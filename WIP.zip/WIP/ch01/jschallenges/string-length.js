let p ="example string";
console.log(p.length);