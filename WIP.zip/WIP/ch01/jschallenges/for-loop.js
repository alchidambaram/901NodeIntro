let total = 0;
let limit = 10;
for (let i = 0; i < limit; i++) {
    total += i;
}
console.log(total);