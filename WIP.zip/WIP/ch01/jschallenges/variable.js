let p="some string";
console.log(p);