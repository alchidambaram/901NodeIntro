

function Person(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
}

Person.prototype.getFullName = function() {
    return this.firstName + this.lastName;
}

const person1 = new Person("Alamelu", "Chidambaram");
console.log(person1.getFullName());
