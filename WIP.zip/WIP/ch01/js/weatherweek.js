const temp = [
    { day: "Monday", high: 80 },
    { day: "Tuesday", high: 85 },
    { day: "Wednesday", high: 65 },
    { day: "Thursday", high: 102 },
    { day: "Friday", high: 95 },
    { day: "Saturday", high: 97 },
    { day: "Sunday", high: 100 }
];
let highTemp = { day: "", high: 0 }
let lowTemp = { day: "", high: 0 };
temp.forEach(function (element) {
    if ((element.high > 0 && lowTemp.high == 0) || element.high < lowTemp.high) {
        lowTemp = element;
    }
    if (highTemp.high == 0 || element.high > highTemp.high) {
        highTemp = element;
    }

});
console.log(`The lowest temparature this week was on ${lowTemp.day} and it was ${lowTemp.high}`);
console.log(`The lowest temparature this week was on ${highTemp.day} and it was ${highTemp.high}`)
