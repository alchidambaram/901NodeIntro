let firstName = "Alamelu";
let lastName = "Chidambaram";
console.log (`Hello ${firstName}${lastName}`);