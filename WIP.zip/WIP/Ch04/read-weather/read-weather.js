const weather = require('./weather.json');
const lodash = require("lodash");
// console.log(weather);
const Promise = require("bluebird");
const fs = Promise.promisifyAll(require("fs"));
let weatherArray = [];
Promise.try(() => {
    return fs.readFileSync("weather.json");
}).then((data) => {
    weatherArray = JSON.parse(data);
    let min = lodash.minBy(weatherArray, function (o) { return o.high; });
    console.log(`Lowest temp ${min.high}`);
    console.log(weatherArray);
    let max = lodash.maxBy(weatherArray, function (o) { return o.high; });
    console.log(`Highest temp ${max.high}`);
}).catch((err) => {
    console.log(`Error: err`);
})
