const express = require("express");
const weather = require('./weather.json');
const Promise = require("bluebird");
const fs = Promise.promisifyAll(require("fs"));
const moment = require("moment");
const pug = require("pug");
const knex = require("knex");
let db = knex(require("../knexfile"));
let router = express.Router();
let studentArray = [{
    nameFirst: "Devin",
    nameLast: "Durgan",
    email: "Devin.Durgan@gmail.com",
    hireDate: moment("01/19/2015", "MM/DD/YYYY")
}, {
    nameFirst: "Cristal",
    nameLast: "Adams",
    email: "Cristal.Adams@live.com",
    hireDate: moment("07/29/2016", "MM/DD/YYYY")
}, {
    nameFirst: "Nettie",
    nameLast: "McGlynn",
    email: "Nettie.McGlynn@gmail.com",
    hireDate: moment("08/29/2015", "MM/DD/YYYY")
}];

router.get("/", (req, res) => {
    // res.send("Hello world! From the main page");
    res.render("index", {
        students: studentArray
    });
});
router.get("/about", (req, res) => {
    // res.send("Hello world! From about page");
    res.render("about");
});
router.get("/class", (req, res) => {
    // res.send("welcome to the class page");
    res.render("class", {
        students: studentArray
    });
});

// router.get("/weather", (req, res) => {
//         Promise.try(() => {
//         return fs.readFileAsync("./routes/weather.json");
//     }).then((data) => {
//         let weatherArray = JSON.parse(data);
//         console.log(`I reached here ${weatherArray}`);
//         res.send(weatherArray);
       
//     }).catch((err) => {
//         console.log(`Error: ${err}`);
//         res.send(err);
//     });
// });

router.get("/weather", (req, res) => {
    Promise.try(() => {
    return db.schema.createTable("customer", (table)  => {
        table.increments("id").primary();
        table.text("firstname");
        table.text("lastname");
        table.text("email");
    });
}).then(() => {
    console.log("Table Created!")
    console.log("Inserting data into customer");
    return db("customer").insert([
        {firstname: "Joe", lastname: "Doe", email:"jdoe@proxie.com"},
        {firstname: "Karl", lastname: "Moxie", email:"kmoxie@proxie.com"},
    ])
}).map((customer) => {
    return studentArray;
}).then((studentArray) => {
  res.send(studentArray);
}).then((customer) => {
console.log("All customers : ", customer);
}).finally(() => {
    db.destroy();
});
});


module.exports = router;


// //  const createdata = function() {
// //      return (`High temp is  ${Math.random() *100}`);
// //  }
// // [{day:"Monday", high:102, low:90},
// // {day:"Tuesday", high:90, low:70},
// // {day:"Wednesday", high:85, low:10}];

// const createdata = function () {
//      console.log(`I reached here`);
//     let weatherArray;
//     Promise.try(() => {
//         return fs.readFileAsync("./routes/weather.json");
//     }).then((data) => {
//         // console.log(`Weather Array : ${data}`);
//         //let weatherArray1 = JSON.parse(data);
//         console.log(`I reached here ${data}`);
//         return data;
//     }).then((weatherArray1) => {
//          console.log(`weatherArray1 : ${weatherArray1}`);
//         weatherArray = weatherArray1;
//         console.log(`Weather Array : ${weatherArray}`);
//         return weatherArray1;
//     }).catch((err) => {
//         console.log(`Error: ${err}`);
//         return err;
//     })
//     console.log(`Weather Array : ${weatherArray}`);
//     return weatherArray;
// }