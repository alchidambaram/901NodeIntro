const expressPromiseRouter = require("express-promise-router");
const unhandledError = require("unhandled-error");
let router = expressPromiseRouter();

router.use(express.static(path.join(__dirname, "public")));

router.use(require("./routes/index.js"));

app.use(router);
let errorReporter = unhandledError((err) => {
    /* This should eventually be hooked into some sort of error reporting
    mechanism. */
    console.error("UNHANDLED ERROR:", err.stack);
});